PCSXr360 v2.1.1a
modified default.xex
07/30/2024 by mLoaD

remove .jpg format
added  .png format 

A modified default.xex so you can now use the PNG fomart 
for the covers in the emulator and no longer the JPG.